from setuptools import setup
setup(
    name="PaqueteEjer",
    author="Rosa",
    version="1.0",
    description="Paquete ejemplo de operaciones y conversión horas,minutos,segundos",
    author_email="aaaa@gmail.com", #opcional
    url="wwww.salesianas.es", #opcional
    packages=[ "PaqueteEjer", "PaqueteEjer.modulos","PaqueteEjer.script"]
)