pares = []

pares = [x for x in range(100) if x%2==0]

print(pares)