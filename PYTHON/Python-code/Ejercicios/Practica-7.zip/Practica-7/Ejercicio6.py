cadena = "papo pepo papa pape po"

cadena = " ".join([palabra.title() for palabra in cadena.split()])

print(cadena)