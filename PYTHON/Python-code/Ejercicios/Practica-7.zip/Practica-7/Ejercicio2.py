def invertirCadena(x):
    invertir = lambda s : s[::-1]
    return invertir(x)

print(invertirCadena("loco"))
print(invertirCadena("saes"))